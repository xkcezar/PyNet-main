### Dependencies

---

##### In order to run the sdk you need to install the following dependencies

- ```python ^3.5.x```
- ```pip install pycryptodome```
- ```pip install pyopenssl```

##### Examples
-  see client/server implementation in the examples folder
