class ExchangeRate():


    def __init__(self, f, t, r):
        self._from = f
        self._to = t
        self.r = r